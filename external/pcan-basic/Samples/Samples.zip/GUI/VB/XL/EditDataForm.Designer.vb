﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class EditDataForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.okButton = New System.Windows.Forms.Button()
        Me.cancelButton = New System.Windows.Forms.Button()
        Me.hexDataGridView = New System.Windows.Forms.DataGridView()
        Me.hex0 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.hex1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.hex2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.hex3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.hex4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.hex5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.hex6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.hex7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.hex8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.hex9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.hex10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.hex11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.hex12 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.hex13 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.hex14 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.hex15 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.hex16 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.hex17 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.hex18 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.hex19 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.hex20 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.hex21 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.hex22 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.hex23 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.hex24 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.hex25 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.hex26 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.hex27 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.hex28 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.hex29 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.hex30 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.hex31 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.hexDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'okButton
        '
        Me.okButton.Location = New System.Drawing.Point(758, 405)
        Me.okButton.Name = "okButton"
        Me.okButton.Size = New System.Drawing.Size(64, 20)
        Me.okButton.TabIndex = 6
        Me.okButton.Text = "OK"
        Me.okButton.UseVisualStyleBackColor = True
        '
        'cancelButton
        '
        Me.cancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cancelButton.Location = New System.Drawing.Point(827, 405)
        Me.cancelButton.Name = "cancelButton"
        Me.cancelButton.Size = New System.Drawing.Size(64, 20)
        Me.cancelButton.TabIndex = 5
        Me.cancelButton.Text = "Cancel"
        Me.cancelButton.UseVisualStyleBackColor = True
        '
        'hexDataGridView
        '
        Me.hexDataGridView.AllowUserToAddRows = False
        Me.hexDataGridView.AllowUserToDeleteRows = False
        Me.hexDataGridView.AllowUserToResizeColumns = False
        Me.hexDataGridView.AllowUserToResizeRows = False
        Me.hexDataGridView.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.hexDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.hexDataGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.hexDataGridView.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.hexDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.hexDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.hex0, Me.hex1, Me.hex2, Me.hex3, Me.hex4, Me.hex5, Me.hex6, Me.hex7, Me.hex8, Me.hex9, Me.hex10, Me.hex11, Me.hex12, Me.hex13, Me.hex14, Me.hex15, Me.hex16, Me.hex17, Me.hex18, Me.hex19, Me.hex20, Me.hex21, Me.hex22, Me.hex23, Me.hex24, Me.hex25, Me.hex26, Me.hex27, Me.hex28, Me.hex29, Me.hex30, Me.hex31})
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.hexDataGridView.DefaultCellStyle = DataGridViewCellStyle2
        Me.hexDataGridView.Location = New System.Drawing.Point(10, 9)
        Me.hexDataGridView.Name = "hexDataGridView"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.Format = "N0"
        DataGridViewCellStyle3.NullValue = Nothing
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.hexDataGridView.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.hexDataGridView.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.hexDataGridView.Size = New System.Drawing.Size(881, 391)
        Me.hexDataGridView.TabIndex = 4
        '
        'hex0
        '
        Me.hex0.HeaderText = "0"
        Me.hex0.Name = "hex0"
        Me.hex0.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'hex1
        '
        Me.hex1.HeaderText = "1"
        Me.hex1.Name = "hex1"
        Me.hex1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'hex2
        '
        Me.hex2.HeaderText = "2"
        Me.hex2.Name = "hex2"
        Me.hex2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'hex3
        '
        Me.hex3.HeaderText = "3"
        Me.hex3.Name = "hex3"
        Me.hex3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'hex4
        '
        Me.hex4.HeaderText = "4"
        Me.hex4.Name = "hex4"
        Me.hex4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'hex5
        '
        Me.hex5.HeaderText = "5"
        Me.hex5.Name = "hex5"
        Me.hex5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'hex6
        '
        Me.hex6.HeaderText = "6"
        Me.hex6.Name = "hex6"
        Me.hex6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'hex7
        '
        Me.hex7.HeaderText = "7"
        Me.hex7.Name = "hex7"
        Me.hex7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'hex8
        '
        Me.hex8.HeaderText = "8"
        Me.hex8.Name = "hex8"
        Me.hex8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'hex9
        '
        Me.hex9.HeaderText = "9"
        Me.hex9.Name = "hex9"
        Me.hex9.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'hex10
        '
        Me.hex10.HeaderText = "10"
        Me.hex10.Name = "hex10"
        Me.hex10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'hex11
        '
        Me.hex11.HeaderText = "11"
        Me.hex11.Name = "hex11"
        Me.hex11.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'hex12
        '
        Me.hex12.HeaderText = "12"
        Me.hex12.Name = "hex12"
        Me.hex12.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'hex13
        '
        Me.hex13.HeaderText = "13"
        Me.hex13.Name = "hex13"
        Me.hex13.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'hex14
        '
        Me.hex14.HeaderText = "14"
        Me.hex14.Name = "hex14"
        Me.hex14.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'hex15
        '
        Me.hex15.HeaderText = "15"
        Me.hex15.Name = "hex15"
        Me.hex15.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'hex16
        '
        Me.hex16.HeaderText = "16"
        Me.hex16.Name = "hex16"
        Me.hex16.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'hex17
        '
        Me.hex17.HeaderText = "17"
        Me.hex17.Name = "hex17"
        Me.hex17.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'hex18
        '
        Me.hex18.HeaderText = "18"
        Me.hex18.Name = "hex18"
        Me.hex18.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'hex19
        '
        Me.hex19.HeaderText = "19"
        Me.hex19.Name = "hex19"
        Me.hex19.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'hex20
        '
        Me.hex20.HeaderText = "20"
        Me.hex20.Name = "hex20"
        Me.hex20.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'hex21
        '
        Me.hex21.HeaderText = "21"
        Me.hex21.Name = "hex21"
        Me.hex21.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'hex22
        '
        Me.hex22.HeaderText = "22"
        Me.hex22.Name = "hex22"
        Me.hex22.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'hex23
        '
        Me.hex23.HeaderText = "23"
        Me.hex23.Name = "hex23"
        Me.hex23.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'hex24
        '
        Me.hex24.HeaderText = "24"
        Me.hex24.Name = "hex24"
        Me.hex24.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'hex25
        '
        Me.hex25.HeaderText = "25"
        Me.hex25.Name = "hex25"
        Me.hex25.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'hex26
        '
        Me.hex26.HeaderText = "26"
        Me.hex26.Name = "hex26"
        Me.hex26.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'hex27
        '
        Me.hex27.HeaderText = "27"
        Me.hex27.Name = "hex27"
        Me.hex27.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'hex28
        '
        Me.hex28.HeaderText = "28"
        Me.hex28.Name = "hex28"
        Me.hex28.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'hex29
        '
        Me.hex29.HeaderText = "29"
        Me.hex29.Name = "hex29"
        Me.hex29.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'hex30
        '
        Me.hex30.HeaderText = "30"
        Me.hex30.Name = "hex30"
        Me.hex30.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'hex31
        '
        Me.hex31.HeaderText = "31"
        Me.hex31.Name = "hex31"
        Me.hex31.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'EditDataForm
        '
        Me.AcceptButton = Me.okButton
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(901, 434)
        Me.Controls.Add(Me.okButton)
        Me.Controls.Add(Me.cancelButton)
        Me.Controls.Add(Me.hexDataGridView)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Name = "EditDataForm"
        Me.Text = "Edit data"
        CType(Me.hexDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Private WithEvents okButton As Button
    Private WithEvents cancelButton As Button
    Private WithEvents hexDataGridView As DataGridView
    Private WithEvents hex0 As DataGridViewTextBoxColumn
    Private WithEvents hex1 As DataGridViewTextBoxColumn
    Private WithEvents hex2 As DataGridViewTextBoxColumn
    Private WithEvents hex3 As DataGridViewTextBoxColumn
    Private WithEvents hex4 As DataGridViewTextBoxColumn
    Private WithEvents hex5 As DataGridViewTextBoxColumn
    Private WithEvents hex6 As DataGridViewTextBoxColumn
    Private WithEvents hex7 As DataGridViewTextBoxColumn
    Private WithEvents hex8 As DataGridViewTextBoxColumn
    Private WithEvents hex9 As DataGridViewTextBoxColumn
    Private WithEvents hex10 As DataGridViewTextBoxColumn
    Private WithEvents hex11 As DataGridViewTextBoxColumn
    Private WithEvents hex12 As DataGridViewTextBoxColumn
    Private WithEvents hex13 As DataGridViewTextBoxColumn
    Private WithEvents hex14 As DataGridViewTextBoxColumn
    Private WithEvents hex15 As DataGridViewTextBoxColumn
    Private WithEvents hex16 As DataGridViewTextBoxColumn
    Private WithEvents hex17 As DataGridViewTextBoxColumn
    Private WithEvents hex18 As DataGridViewTextBoxColumn
    Private WithEvents hex19 As DataGridViewTextBoxColumn
    Private WithEvents hex20 As DataGridViewTextBoxColumn
    Private WithEvents hex21 As DataGridViewTextBoxColumn
    Private WithEvents hex22 As DataGridViewTextBoxColumn
    Private WithEvents hex23 As DataGridViewTextBoxColumn
    Private WithEvents hex24 As DataGridViewTextBoxColumn
    Private WithEvents hex25 As DataGridViewTextBoxColumn
    Private WithEvents hex26 As DataGridViewTextBoxColumn
    Private WithEvents hex27 As DataGridViewTextBoxColumn
    Private WithEvents hex28 As DataGridViewTextBoxColumn
    Private WithEvents hex29 As DataGridViewTextBoxColumn
    Private WithEvents hex30 As DataGridViewTextBoxColumn
    Private WithEvents hex31 As DataGridViewTextBoxColumn
End Class
