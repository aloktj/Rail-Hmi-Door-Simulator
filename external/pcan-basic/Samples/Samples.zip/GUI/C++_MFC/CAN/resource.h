//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PCANBasicExample.rc
//
#define IDR_MAINFRAME                   1
#define IDC_BTNINIT                     5
#define IDC_BTNRELEASE                  6
#define IDC_BTNWRITE                    7
#define IDD_PCANBASICEXAMPLE_DIALOG     102
#define IDI_ICON1                       130
#define IDC_CBBHWS                      1000
#define IDC_CBBCHANNEL                  1000
#define IDC_CBBBAUDRATES                1001
#define IDC_CBBMSGTYPE                  1002
#define IDC_LSTMESSAGES                 1006
#define IDC_TXTID                       1007
#define IDC_NUDLENGTH                   1008
#define IDC_TXTLENGTH                   1009
#define IDC_TXTDATA0                    1010
#define IDC_CHBEXTENDED                 1011
#define IDC_TXTDATA1                    1012
#define IDC_TXTDATA2                    1013
#define IDC_TXTDATA3                    1014
#define IDC_TXTDATA4                    1015
#define IDC_TXTDATA5                    1016
#define IDC_TXTDATA6                    1017
#define IDC_TXTDATA7                    1018
#define IDC_CHBREMOTE                   1019
#define IDC_CHBTIMESTAMP                1027
#define IDC_TXTFILTERFROM               1031
#define IDC_RDBTIMER                    1032
#define IDC_RADIO_BY_EVENT              1033
#define IDC_RDBEVENT                    1033
#define IDC_BUTTON_HWREFRESH            1034
#define IDC_NUDFILTERFROM               1035
#define IDC_RADIOFILTEROPEN             1036
#define IDC_RADIOFILTERCLOSE            1037
#define IDC_RADIOFILTERCUSTOM           1038
#define IDC_TXTFILTERTO                 1039
#define IDC_NUDFILTERTO                 1040
#define IDC_BUTTONFILTERAPPLY           1041
#define IDC_BUTTONFILTERQUERY           1042
#define IDC_CHBFILTEREXTENDED           1043
#define IDC_LISTINFO                    1044
#define IDC_RDBMANUAL                   1045
#define IDC_BUTTONREAD                  1046
#define IDC_BUTTONREADINGCLEAR          1047
#define IDC_BUTTONVERSION               1048
#define IDC_BUTTON2                     1049
#define IDC_BUTTONINFOCLEAR             1049
#define IDC_COMBOPARAMETER              1050
#define IDC_RADIOPARAMACTIVE            1051
#define IDC_RADIOPARAMINACTIVE          1052
#define IDC_TXTPARAMDEVNUMBER           1053
#define IDC_NUDPARAMDEVNUMBER           1054
#define IDC_BUTTONPARAMSET              1055
#define IDC_BUTTONPARAMGET              1056
#define IDC_BUTTONSTATUS                1058
#define IDC_BUTTON3                     1059
#define IDC_BUTTONRESET                 1059
#define IDC_LABAUDRATE                  1066
#define IDC_LALENGTH                    1071
#define IDC_LA_DEVICEORDELAY            1072

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1073
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
